namespace DataBase.dataBase
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class Context : DbContext
    {
        public Context()
            : base("name=Context")
        {
        }

        public virtual DbSet<Documents> Documents { get; set; }
        public virtual DbSet<Entrances> Entrances { get; set; }
        public virtual DbSet<Entrants> Entrants { get; set; }
        public virtual DbSet<Specialties> Specialties { get; set; }
        public virtual DbSet<SpecSubjects> SpecSubjects { get; set; }
        public virtual DbSet<Subjects> Subjects { get; set; }
        public virtual DbSet<sysdiagrams> sysdiagrams { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Documents>()
                .Property(e => e.number_document)
                .IsFixedLength();

            modelBuilder.Entity<Documents>()
                .Property(e => e.number_regictration)
                .IsFixedLength();

            modelBuilder.Entity<Entrances>()
                .Property(e => e.number_subject)
                .IsFixedLength();

            modelBuilder.Entity<Entrances>()
                .Property(e => e.mark)
                .IsFixedLength();

            modelBuilder.Entity<Entrants>()
                .HasMany(e => e.Documents)
                .WithRequired(e => e.Entrants)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Entrants>()
                .HasMany(e => e.Entrances)
                .WithRequired(e => e.Entrants)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Specialties>()
                .Property(e => e.number_specialty)
                .IsFixedLength();

            modelBuilder.Entity<Specialties>()
                .Property(e => e.name_specialty)
                .IsFixedLength();

            modelBuilder.Entity<Specialties>()
                .Property(e => e.edu_year)
                .IsFixedLength();

            modelBuilder.Entity<Specialties>()
                .Property(e => e.budgetary_place)
                .IsFixedLength();

            modelBuilder.Entity<Specialties>()
                .Property(e => e.commercial_place)
                .IsFixedLength();

            modelBuilder.Entity<SpecSubjects>()
                .Property(e => e.number_specialty)
                .IsFixedLength();

            modelBuilder.Entity<SpecSubjects>()
                .Property(e => e.number_subject)
                .IsFixedLength();

            modelBuilder.Entity<Subjects>()
                .Property(e => e.number_subject)
                .IsFixedLength();

            modelBuilder.Entity<Subjects>()
                .Property(e => e.name_subject)
                .IsFixedLength();

            modelBuilder.Entity<Subjects>()
                .Property(e => e.number_specialty)
                .IsFixedLength();

            modelBuilder.Entity<Subjects>()
                .HasMany(e => e.Entrances)
                .WithRequired(e => e.Subjects)
                .WillCascadeOnDelete(false);
        }
    }
}

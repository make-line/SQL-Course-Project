namespace DataBase.dataBase
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Specialties
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Specialties()
        {
            Subjects = new HashSet<Subjects>();
        }

        [Key]
        [StringLength(10)]
        public string number_specialty { get; set; }

        [StringLength(10)]
        public string name_specialty { get; set; }

        [StringLength(10)]
        public string edu_year { get; set; }

        [StringLength(10)]
        public string budgetary_place { get; set; }

        [StringLength(10)]
        public string commercial_place { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Subjects> Subjects { get; set; }
    }
}

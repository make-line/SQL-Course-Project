namespace DataBase.dataBase
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Documents
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(50)]
        public string number_entrant { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(10)]
        public string number_document { get; set; }

        [StringLength(10)]
        public string number_regictration { get; set; }

        public virtual Entrants Entrants { get; set; }
    }
}

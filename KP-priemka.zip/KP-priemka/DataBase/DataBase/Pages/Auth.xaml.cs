﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DataBase.dataBase;

namespace DataBase.Pages
{
    /// <summary>
    /// Логика взаимодействия для Auth.xaml
    /// </summary>
    public partial class Auth : Page
    {
        MainWindow main;
        public Auth(MainWindow main)
        {
            this.main = main;
            InitializeComponent();
        }


        private void EntryButton_Click(object sender, RoutedEventArgs e)
        {
            bool check = false;
            bool isAdmin = false;
            foreach (dataBase.Entrants entrants in main.bd.Entrants)
            {
                if (login.Text == entrants.login && password.Password == entrants.password)
                {
                    check = true;
                    isAdmin = (bool)entrants.isAdmin;
                }
            }

            if (check)
            {
                if (isAdmin)
                {
                    main.MainFrame.Navigate(new Pages.Admin(main));
                }
                else
                {
                    main.MainFrame.Navigate(new Pages.EntrantVersion(main));
                }
            }
            else
            {
                MessageBox.Show("Неверные данные");
            }

        }
    }
}

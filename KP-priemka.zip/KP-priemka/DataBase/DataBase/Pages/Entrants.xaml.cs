﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DataBase.dataBase;

namespace DataBase.Pages
{
    /// <summary>
    /// Логика взаимодействия для Entrants.xaml
    /// </summary>
    public partial class Entrants : Page
    {
        MainWindow main;
        Record nowSp;
        public Entrants(MainWindow main)
        {
            this.main = main;

            InitializeComponent();
            foreach (dataBase.Entrants en in main.bd.Entrants)
            {
                Record record = new Record();
                record.name = en.name;
                record.surname = en.surname;
                record.docnum = en.certificate_number;
                record.mail = en.mail;
                record.login = en.login;
                record.password = en.password;
                record.isAdmin = en.isAdmin.ToString();
                record.entrants = en;
                entrants.Items.Add(record);
            }
        }
        public class Record
        {
            public string num { get; set; }
            public string name { get; set; }
            public string surname { get; set; }
            public string docnum { get; set; }
            public string mail { get; set; }
            public string login { get; set; }
            public string password { get; set; }
            public string isAdmin { get; set; }
            public dataBase.Entrants entrants { get; set; }
        }

        private void delete_Click(object sender, RoutedEventArgs e)
        {
            if (entrants.SelectedIndex != -1)
            {
                main.bd.Entrants.Remove(((Record)entrants.SelectedItem).entrants);
                entrants.Items.Remove((Record)entrants.SelectedItem);
                main.bd.SaveChanges();
            }
            else
            {
                MessageBox.Show("Ничего не выделено");
            }
        }

        private void add_Click(object sender, RoutedEventArgs e)
        {
            int num = 0;
            foreach (dataBase.Entrants ent in main.bd.Entrants)
            {
                if (num.ToString() == ent.number_entrant)
                {
                    break;
                }
            }
            dataBase.Entrants en = new dataBase.Entrants();
            en.number_entrant = num.ToString();
            en.name = name.Text;
            en.surname = surname.Text;
            en.certificate_number = docnum.Text;
            en.mail = mail.Text;
            en.login = login.Text;
            en.password = password.Text;
            en.isAdmin = Convert.ToBoolean(isAdmin.Text);
            main.bd.Entrants.Add(en);
            main.bd.SaveChanges();

            Record record = new Record();
            record.num = num.ToString();
            record.name = name.Text;
            record.surname = surname.Text;
            record.docnum = docnum.Text;
            record.mail = mail.Text;
            record.login = login.Text;
            record.password = password.Text;
            record.isAdmin = isAdmin.Text;
            record.entrants = en;
            entrants.Items.Add(record);
        }

        private void change_Click(object sender, RoutedEventArgs e)
        {
            nowSp = ((Record)entrants.SelectedItem);
            name.Text = nowSp.entrants.name;
            surname.Text = nowSp.entrants.surname;
            docnum.Text = nowSp.entrants.certificate_number;
            mail.Text = nowSp.entrants.mail;
            login.Text = nowSp.entrants.login;
            password.Text = nowSp.entrants.password;
            isAdmin.Text = nowSp.entrants.isAdmin.ToString();
        }

        private void save_Click(object sender, RoutedEventArgs e)
        {
            nowSp.entrants.name = name.Text;
            nowSp.entrants.surname = surname.Text;
            nowSp.entrants.certificate_number = docnum.Text;
            nowSp.entrants.mail = mail.Text;
            nowSp.entrants.login = login.Text;
            nowSp.entrants.password = password.Text;
            nowSp.entrants.isAdmin = Convert.ToBoolean(isAdmin.Text);
            name.Text = nowSp.entrants.name;
            surname.Text = nowSp.entrants.surname;
            docnum.Text = nowSp.entrants.certificate_number;
            mail.Text = nowSp.entrants.mail;
            login.Text = nowSp.entrants.login;
            password.Text = nowSp.entrants.password;
            isAdmin.Text = nowSp.entrants.isAdmin.ToString();
            main.bd.SaveChanges();
        }
    }
}

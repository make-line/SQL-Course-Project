﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DataBase.dataBase;

namespace DataBase.Pages
{
    /// <summary>
    /// Логика взаимодействия для Specialties.xaml
    /// </summary>
    public partial class Specialties : Page
    {
        MainWindow main;
        Record nowSp;
        public Specialties(MainWindow main)
        {
            this.main = main;
           
            InitializeComponent();

            foreach (dataBase.Specialties sp in main.bd.Specialties)
            {
                Record record = new Record();
                record.name = sp.name_specialty.ToString();
                record.year = sp.edu_year;
                record.place1 = sp.budgetary_place;
                record.place2 = sp.commercial_place;
                record.specialties = sp;
                specialties.Items.Add(record);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (specialties.SelectedIndex != -1)
            {
                main.bd.Specialties.Remove(((Record)specialties.SelectedItem).specialties);
                specialties.Items.Remove((Record)specialties.SelectedItem);
                main.bd.SaveChanges();
            }
            else
            {
                MessageBox.Show("Ничего не выделено");
            }
        }

        private void Button_Click2(object sender, RoutedEventArgs e)
        {
            nowSp.specialties.name_specialty = name.Text;
            nowSp.specialties.edu_year = year.Text;
            nowSp.specialties.budgetary_place = place1.Text;
            nowSp.specialties.commercial_place = place2.Text;
            nowSp.name = nowSp.specialties.name_specialty;
            nowSp.year = nowSp.specialties.edu_year;
            nowSp.place1 = nowSp.specialties.budgetary_place;
            nowSp.place2 = nowSp.specialties.commercial_place;
            main.bd.SaveChanges();
        }

        private void Button_Click3(object sender, RoutedEventArgs e)
        {
            nowSp = ((Record)specialties.SelectedItem);
            name.Text = nowSp.specialties.name_specialty;
            year.Text = nowSp.specialties.edu_year;
            place1.Text = nowSp.specialties.budgetary_place;
            place2.Text = nowSp.specialties.commercial_place;

        }

        private void Button_Click4(object sender, RoutedEventArgs e)
        {
            int num = 0;
            foreach (dataBase.Specialties s in main.bd.Specialties)
            {
                if (num.ToString() == s.number_specialty)
                    break;
            }




            dataBase.Specialties sp = new dataBase.Specialties();
            sp.number_specialty = num.ToString();
            sp.name_specialty = name.Text;
            sp.edu_year = year.Text;
            sp.budgetary_place = place1.Text;
            sp.commercial_place = place2.Text;
            main.bd.Specialties.Add(sp);
            main.bd.SaveChanges();

            Record record = new Record();
            record.num = num.ToString();
            record.name = name.Text;
            record.year = year.Text;
            record.place1 = place1.Text;
            record.place2 = place2.Text;
            record.specialties = sp;
            specialties.Items.Add(record);

        }
    }

    public class Record
    {
        public string num { get; set; }
        public string name { get; set; }
        public string year { get; set; }
        public string place1 { get; set; }
        public string place2 { get; set; }
        public dataBase.Specialties specialties { get; set; }
    }
}
